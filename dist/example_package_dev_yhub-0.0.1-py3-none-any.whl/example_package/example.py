def add_one(number): return + 1
